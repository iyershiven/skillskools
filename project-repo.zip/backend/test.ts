import express from 'express';
const app = express();
app.listen(5001, () => console.log('Listening on 5001'));
